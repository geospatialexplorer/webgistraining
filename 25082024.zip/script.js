// function clickButton() {
//   //   alert("you clicked button");
//   document.querySelector("p").textContent = "Hello World";
//   document.querySelector("p").style.backgroundColor = "green";
// }

// document.getElementById("btn").addEventListener("click", clickButton);

// const firstName = "Stephen";

// console.log(firstName);

// let name = "Stephen";

// console.log(typeof name);
// let age = 29;
// console.log(typeof age);
// const birthYear = 1995;
// console.log(typeof birthYear);

// let gender;
// console.log(typeof gender);

// //data type

// //string =>
// //Number===> float number
// //boolean ==> true or false
// //undefined==>empty
// //null==>empty

// let isBirthYear1995 = true;
// console.log(typeof isBirthYear1995);
// // ES6==> ECMA script
// let age = 31;

// age = 32;
// // console.log(age);
// const birthYear = 1995;
// // birthYear = 1996;

// const PI = 3.14;

// var age = 32;

// // for (){

// // }

// age = 34;

//const country
//population
//
//display the variable type

//syntax for creating variable

// keyword  variableName = value
//const     country      = "India"
//let       population   =1000000

// let x = 5;
// let y = 6;

// let multiplication = x * y;
// let addition = x + y;
// let substraction = x - y;

// console.log(multiplication, "This is multiplication result");
// console.log(addition, "This is addition result");
// console.log(substraction, "This is substraction result");

// console.log(x * y, "the result");

//assignment

// two variables you need to create
// const name="Stephen"
// let age= 29
// age="29"
// let x=10
//let y='20'

//1) if you add name with age ? what is the result
//2) add name with string age ? What is the result
//3) perform addition,substraction,multiplication,division
//4) if you get error findout the reason
//5) operator precedence

// let a = 10;
// let b = 20;

// let c = a + b;

// console.log(c);

// let d = 89;
// let e = 64;

// let f = d + e;

// console.log(f);

//syntax for the function

// function functionName(parameter1, parameter2) {
//   //write code here
//   let number1 = parameter1;
//   let number2 = parameter2;

//   console.log(number1 + number2);
// }

// let number1 = prompt("Enter the Number 1");
// let number2 = prompt("Enter the Number 2");

// function calculator() {
//   let number1 = Number(prompt("Enter the Number 1"));
//   let number2 = Number(prompt("Enter the Number 2"));
//   addNumbers();
// }
// //sample code for the funtion
// function addNumbers() {
//   console.log(
//     "The addition of " + number1 + " and " + number2 + " is",
//     number1 + number2
//   );
// }

//assignment

// multiplication

// division

//calculator application

// addNumbers(8, 6);
// addNumbers(19, 6);
// addNumbers(8, 30);
// addNumbers(8, 54);

// console.log(fruits[1]);

// fruits[1] = "lemon";

// console.log(fruits[1]);

// console.log(fruits);

// //array length

// console.log(fruits.length);

// console.log(fruits[fruits.length - 1]);
// //add the elements to array
// fruits.push("tomato");

// console.log(fruits);

// console.log(fruits.unshift("brinjal"));

// console.log(fruits);

// //object

// const person = {
//   name: "Stephen",
//   fruitsBucket: ["apple", "orange", "mango", "pineapple"],
//   moviesWatched: {
//     movieName: ["Kalki AD", "Manjumel Boys", "DJ"],
//   },
// };

// function returnMovieWatched() {
//   prompt("Please Enter the User Name");
//   console.log(person.moviesWatched.movieName[0]);
// }

// returnMovieWatched();
// console.log(person["name"]);
// console.log(person.moviesWatched);

//Assignment
//create four users
//create function
//stephen
// stephen watched the movies kalki AD,Manjumel Boys,DJ

// const fruits = ["mango", "apple", "orange"];
//arrays and objects

// const fruits = ["apple", "orange", "mango", "pineapple", "lemon"];

// let fruitsNameList = document.getElementById("fruitsName");

// fruits.forEach(function (fruit) {
//   if (fruit == "mango") {
//     let listElement = document.createElement("li");
//     listElement.textContent = fruit;
//     fruitsNameList.appendChild(listElement);
//   } else if (fruit == "lemon") {
//     let listElement = document.createElement("li");
//     listElement.textContent = fruit;
//     fruitsNameList.appendChild(listElement);
//   }
// });

// console.log(2 + 2);

// console.log(85 + 66);

// for (i = 0; i < fruits.length; i++) {
//   debugger;
//   let listElement = document.createElement("li");
//   listElement.textContent = fruits[i];
//   fruitsNameList.appendChild(listElement);
// }

// console.log(fruits[0]);

// document.write(fruits[0]);
// //assignment
// //reverse an array without default function
// function addNumber() {
//   return 78 * 3;
// }
// let addedNumber = addNumber();

// console.log(5 + addNumber());

//
console.log(1);

// setTimeout(() => {
//   console.log(3);
// }, 3000);

//map data

console.log(2);

function findTemperature() {
  let cityName = document.getElementById("cityName").textContent;

  //geocoding api
  fetch(
    `https://geocoding-api.open-meteo.com/v1/search?name=${cityName}&count=5&language=en&format=json`
  ).then((response) => {
    response.json().then((data) => {
      console.log(data.results);
      let latitude = data.results[0].latitude;
      let longitude = data.results[0].longitude;
      //temperature api
      fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m`
      ).then((response) => {
        response.json().then((weather) => {
          // console.log(temperature);
          let temperature = weather.current.temperature_2m;
          document.getElementById("tempValue").textContent = temperature;
        });
      });
    });
  });

  //   fetch(
  //     "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"
  //   )
  //     .then((response) => {
  //       console.log(response);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
}
document.getElementById("btn1").addEventListener("click", findTemperature());

// findTemperature();
